@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.services.store.techmatrix.co.jp/")
package jp.co.techmatrix.store.services.soap;
